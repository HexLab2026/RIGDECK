# RigDeck - Android app

Fullscreen native client for the ETS2 cab panel. Finds the PC by itself
(UDP broadcast on port 8721), keeps the screen awake for the whole drive,
survives server restarts, and the seatbelt chime plays without needing a
first tap (browsers block that, the app does not).

Needs `rigdeck.py (or RigDeck.exe)` **v1.7+** running on the gaming PC - that script
is the half that presses keys and reads telemetry; the app is the cockpit
screen for it.

## Build it once (about 15 minutes, all free)

1. Install **Android Studio** from developer.android.com/studio and open
   this folder (`File > Open`). Let it sync; accept any Gradle/plugin
   update prompts it suggests.
2. On the phone: Settings > About phone > tap **Build number** 7 times,
   then Settings > Developer options > enable **USB debugging**.
3. Plug the phone into the PC, allow the debugging prompt on the phone,
   pick your phone in the device dropdown, press the green **Run** button.
   The app installs and launches.

To get a shareable APK instead: `Build > Build App Bundle(s) / APK(s) >
Build APK(s)`, then sideload `app/build/outputs/apk/debug/app-debug.apk`.

## Troubleshooting

- **BRIDGE NOT FOUND**: script not running, phone on a different Wi-Fi
  band with client isolation, or Windows Firewall blocking Python for
  UDP - re-tick both Private boxes for Python in firewall settings.
  The manual IP box always works as a fallback.
- Discovery replies come from UDP port 8721; the panel itself is HTTP
  port 8720. Both need to be allowed for python.exe.
