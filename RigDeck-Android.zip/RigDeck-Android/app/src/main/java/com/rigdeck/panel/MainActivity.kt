package com.rigdeck.panel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * RigDeck - Android client.
 *
 * Thin fullscreen shell around the cab panel served by ets2_cab_panel.py
 * (v1.7+) on the gaming PC. Finds the PC automatically via UDP broadcast
 * on port 8721, keeps the screen awake, and reconnects when the server
 * restarts. Manual IP entry is available as a fallback.
 */
class MainActivity : Activity() {

    companion object {
        const val MAGIC = "RIGDECK_DISCOVER"
        const val REPLY_PREFIX = "RIGDECK"
        const val DISCOVERY_PORT = 8721
        const val PANEL_PORT = 8600   // fallback only; discovery sends the live port
        const val PREFS = "rigdeck"
        val ACCENT = Color.parseColor("#FF6A2B")
        val STEEL = Color.parseColor("#C7CDD2")
        val INK = Color.parseColor("#14171B")
        val LAB = Color.parseColor("#7A838C")
        val LINE = Color.parseColor("#2A3038")
    }

    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private lateinit var ipBox: EditText
    private lateinit var connectBtn: Button
    private lateinit var retryBtn: Button
    private var connecting = false
    private var pageFailed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        goImmersive()
        scan()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(INK) }

        web = WebView(this).apply {
            setBackgroundColor(INK)
            keepScreenOn = true
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(false)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!pageFailed) hideOverlay()
                }
                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        pageFailed = true
                        showOverlay("BRIDGE OFFLINE", showEntry = true, showRetry = true)
                    }
                }
            }
        }

        val logo = TextView(this).apply {
            text = "RIGDECK"
            setTextColor(STEEL)
            textSize = 26f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "SCANNING FOR BRIDGE"
            setTextColor(LAB)
            textSize = 13f
            letterSpacing = 0.2f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(26))
        }
        ipBox = EditText(this).apply {
            hint = "PC IP  e.g. 192.168.1.80"
            setTextColor(Color.WHITE)
            setHintTextColor(LAB)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        connectBtn = Button(this).apply {
            text = "CONNECT TO IP"
            setTextColor(ACCENT)
            setBackgroundColor(LINE)
            visibility = View.GONE
            setOnClickListener {
                val t = ipBox.text.toString().trim()
                if (t.isNotEmpty()) scan(t)
            }
        }
        retryBtn = Button(this).apply {
            text = "RETRY SCAN"
            setTextColor(INK)
            setBackgroundColor(ACCENT)
            visibility = View.GONE
            setOnClickListener { scan() }
        }

        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(INK)
            setPadding(dp(32), 0, dp(32), 0)
            addView(logo)
            addView(status)
            addView(retryBtn, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(20) })
            addView(ipBox, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })
            addView(connectBtn, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        }

        val fill = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        root.addView(web, fill)
        root.addView(overlay, fill)
        setContentView(root)
    }

    private fun showOverlay(msg: String, showEntry: Boolean = false, showRetry: Boolean = false) {
        status.text = msg
        retryBtn.visibility = if (showRetry) View.VISIBLE else View.GONE
        ipBox.visibility = if (showEntry) View.VISIBLE else View.GONE
        connectBtn.visibility = if (showEntry) View.VISIBLE else View.GONE
        overlay.visibility = View.VISIBLE
    }

    private fun hideOverlay() { overlay.visibility = View.GONE }

    /** Broadcast the magic word, take the first PC that answers. */
    private fun probe(sock: DatagramSocket, magic: String, prefix: String): String? {
        return try {
            val payload = magic.toByteArray()
            val bcast = InetAddress.getByName("255.255.255.255")
            sock.send(DatagramPacket(payload, payload.size, bcast, DISCOVERY_PORT))
            val buf = ByteArray(64)
            val pkt = DatagramPacket(buf, buf.size)
            sock.receive(pkt)
            val reply = String(pkt.data, 0, pkt.length).trim()
            if (reply.startsWith(prefix)) {
                val port = reply.split(" ").getOrNull(1)?.toIntOrNull() ?: PANEL_PORT
                "${pkt.address.hostAddress}:$port"
            } else null
        } catch (_: Exception) { null }
    }

    /** Returns "ip:port" from the RigDeck discovery reply. */
    private fun discover(): String? {
        return try {
            DatagramSocket().use { sock ->
                sock.broadcast = true
                sock.soTimeout = 1200
                repeat(3) {
                    probe(sock, MAGIC, REPLY_PREFIX)?.let { return it }
                }
                null
            }
        } catch (_: Exception) { null }
    }

    private fun scan(manualIp: String? = null) {
        if (connecting) return
        connecting = true
        pageFailed = false
        showOverlay(if (manualIp != null) "CONNECTING" else "SCANNING FOR BRIDGE")
        Thread {
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            // manual entry may omit the port; discovery always includes it
            val target = when {
                manualIp != null -> if (manualIp.contains(":")) manualIp else "$manualIp:$PANEL_PORT"
                else -> discover() ?: prefs.getString("last_target", null)
            }
            runOnUiThread {
                connecting = false
                if (target == null) {
                    showOverlay("BRIDGE NOT FOUND\nrun RigDeck on the PC,\nsame Wi-Fi - or enter the IP",
                        showEntry = true, showRetry = true)
                } else {
                    prefs.edit().putString("last_target", target).apply()
                    status.text = "LINKING $target"
                    web.loadUrl("http://$target/")
                }
            }
        }.start()
    }

    private fun goImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }
}
